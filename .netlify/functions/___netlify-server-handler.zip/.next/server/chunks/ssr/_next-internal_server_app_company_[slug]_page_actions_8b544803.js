module.exports=[42073,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_company_%5Bslug%5D_page_actions_8b544803.js.map