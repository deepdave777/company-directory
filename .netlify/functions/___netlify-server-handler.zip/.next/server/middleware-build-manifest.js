globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/20d1a56625def336.js",
    "static/chunks/806bdb8e4a6a9b95.js",
    "static/chunks/aee6c7720838f8a2.js",
    "static/chunks/7f07916cc0aa13ba.js",
    "static/chunks/turbopack-339ed8aaed805470.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];